# Pre Requisites
1. NodeJS : >=v14.17.4
2. NPM : >=6.14.14

# Installation
1. npm install
2. npm install -g .
3. node bin/index.js -t "Associate UX Designer emea"
